package com.example.polypaintapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.navigation.findNavController
import com.beust.klaxon.JsonArray
import com.beust.klaxon.JsonObject
import kotlinx.android.synthetic.main.fragment_waiting_room.*
import kotlinx.android.synthetic.main.games_row.*
import android.view.KeyEvent.KEYCODE_BACK
import android.widget.Toast
import androidx.navigation.NavOptions
import com.google.gson.Gson
import com.google.gson.JsonParser
import nl.dionsegijn.konfetti.models.Shape
import nl.dionsegijn.konfetti.models.Size
import org.json.JSONObject

enum class MatchEditActions {
    AddAI,
    RemoveAI,
    ChangeAI,
    SwitchTeam,
}

enum class Team {
    TeamA,
    TeamB,
}


class Fragment_WaitingRoom : Fragment() {
    var onLeave = false


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_waiting_room, container, false)
        //Back pressed Logic for fragment
        v.setFocusableInTouchMode(true)
        v.requestFocus()
        v.setOnKeyListener(object : View.OnKeyListener {
            override fun onKey(v: View, keyCode: Int, event: KeyEvent): Boolean {
                if (event.getAction() === KeyEvent.ACTION_DOWN) {
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
                        val json = JSON()
                        val request = MatchRequest(User.username, WaitingRoom.name + CurrentGameMode.gameMode.toString())
                        val room = Room(User.username,WaitingRoom.name)
                        SocketUser.socket.leaveRoom(json.toJson(room))
                        SocketUser.joinedChannels.remove(WaitingRoom.name)
                        SocketUser.socket.leaveMatch(json.toJson(request))
                        SocketUser.joinedChannels.remove(WaitingRoom.name)
                        val intent = Intent(context, Game_Modes::class.java)
                        startActivity(intent)
                    }
                }
                return false
            }
        })
        // Inflate the layout for this fragment
        return v
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {


        //activity?.supportFragmentManager?.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)

        onEditMatch()
        onMatchStarted()
        Game_name.text = WaitingRoom.name
        Channel.name = WaitingRoom.name

        start_match_button.setOnClickListener {
            val json = com.google.gson.JsonObject()
            json.addProperty("id", WaitingRoom.name + CurrentGameMode.gameMode.toString())
            SocketUser.socket.socket.emit("startMatch", json)
        }

        updateView()


    }


    override fun onDestroyView() {
        onLeave = true
        val json = JSON()
        val request = MatchRequest(User.username, WaitingRoom.name + CurrentGameMode.gameMode.toString())
        SocketUser.socket.leaveMatch(json.toJson(request))
        super.onDestroyView()
    }


    fun updateView() {
        when(CurrentGameMode.gameMode) {
            0 -> {
                var cGame: ClassicGame = WaitingRoom.Game as ClassicGame
                nb_rounds_number?.text = cGame.nbRounds.toString()
                var teamA: String = ""
                var teamB: String = ""
                for(players in cGame.teamA){
                    teamA += players + ", "

                }
                for(players in cGame.teamB){
                    teamB += players + ", "

                }
                if(cGame.teamA.contains("Raging guy (Ai Player)")){//A COMPLETER PR LES AUTRES AI
                    add_bot_2.text = "REMOVE BOT"
                } else {
                    add_bot_2.text = "ADD BOT"
                }

                if(cGame.teamB.contains("Raging guy (Ai Player)")){
                    add_bot_1.text = "REMOVE BOT"
                } else {
                    add_bot_1.text = "ADD BOT"
                }
                Player1_name.text = teamA
                player2_name.text = teamB
                add_bot_1.visibility = View.VISIBLE
                add_bot_2.visibility = View.VISIBLE
                add_bot_1.setOnClickListener {
                    if(add_bot_1.text == "ADD BOT"){
                        val json = com.google.gson.JsonObject()
                        json.addProperty("id", WaitingRoom.name+CurrentGameMode.gameMode)
                        json.addProperty("action", MatchEditActions.AddAI.ordinal)
                        json.addProperty("options", Team.TeamA.ordinal)
                        add_bot_1.text = "REMOVE BOT"
                        val json2 = com.google.gson.JsonObject()
                        json2.addProperty("name", WaitingRoom.name)
                        json2.addProperty("type", "2")
                        SocketUser.socket.socket.emit("editMatch", json)
                        SocketUser.socket.socket.emit("addBot",json2 )
                    }
                    else {
                        add_bot_1.text = "ADD BOT"
                        val json = com.google.gson.JsonObject()
                        json.addProperty("id", WaitingRoom.name+CurrentGameMode.gameMode)
                        json.addProperty("action", MatchEditActions.RemoveAI.ordinal)
                        json.addProperty("options", Team.TeamA.ordinal)
                        val json2 = com.google.gson.JsonObject()
                        json2.addProperty("name", WaitingRoom.name)
                        json2.addProperty("type", "3")
                        SocketUser.socket.socket.emit("editMatch", json)
                        SocketUser.socket.socket.emit("addBot",json2 )
                    }
                }
                add_bot_2.setOnClickListener {
                    if(add_bot_2.text == "ADD BOT"){
                        add_bot_2.text = "REMOVE BOT"
                        val json = com.google.gson.JsonObject()
                        json.addProperty("id", WaitingRoom.name+CurrentGameMode.gameMode)
                        json.addProperty("action", MatchEditActions.AddAI.ordinal)
                        json.addProperty("options", Team.TeamB.ordinal)
                        val json2 = com.google.gson.JsonObject()
                        json2.addProperty("name", WaitingRoom.name)
                        json2.addProperty("type", "0")
                        SocketUser.socket.socket.emit("editMatch", json)
                        SocketUser.socket.socket.emit("addBot",json2 )
                    }
                    else {
                        add_bot_2.text = "ADD BOT"
                        val json = com.google.gson.JsonObject()
                        json.addProperty("id", WaitingRoom.name+CurrentGameMode.gameMode)
                        json.addProperty("action", MatchEditActions.RemoveAI.ordinal)
                        json.addProperty("options", Team.TeamB.ordinal)
                        val json2 = com.google.gson.JsonObject()
                        json2.addProperty("name", WaitingRoom.name)
                        json2.addProperty("type", "1")
                        SocketUser.socket.socket.emit("editMatch", json)
                        SocketUser.socket.socket.emit("addBot",json2 )
                    }
                }
            }

            1 -> {
                var coGame : CoopGame = WaitingRoom.Game as CoopGame
                nb_rounds_number.text = coGame.nbRounds.toString()
                var playerss: String = ""
                for(players in coGame.players){
                    playerss += players + ", "

                }
                Player1_name.text = playerss
                VS_text.visibility = View.GONE
                player2_name.visibility = View.GONE
            }
            2 -> {
                var dGame : DuelGame = WaitingRoom.Game as DuelGame
                nb_rounds_number.text = dGame.nbRounds.toString()
                Player1_name.text = dGame.player1
                player2_name.text = dGame.player2
            }

            3 -> {
                view?.findNavController()?.navigate(R.id.action_fragment_WaitingRoom_to_fragment_Inmatch)
            }

        }
    }


    fun onMatchStarted() {
        SocketUser.socket.socket.on("matchStarted") { data ->
            val matchJson = JsonParser().parse(data[0].toString()).asJsonObject
            var matchId = matchJson.get("content").toString().removePrefix("\"")
            matchId = matchId.removeSuffix("\"")
            var gameType = -1
            if (WaitingRoom.Game is ClassicGame) {
                gameType = GameModes.Classic.ordinal
            } else if (WaitingRoom.Game is DuelGame) {
                gameType = GameModes.Duel.ordinal
            } else if (WaitingRoom.Game is CoopGame) {
                gameType = GameModes.Coop.ordinal
            } else if (WaitingRoom.Game is SoloGame) {
                gameType = GameModes.Solo.ordinal
            }
            val currentId = WaitingRoom.name + gameType.toString()
            if (matchId == currentId) {
                view?.findNavController()?.navigate(R.id.action_fragment_WaitingRoom_to_fragment_Inmatch)
            } else {
                activity?.runOnUiThread {
                    Toast.makeText(activity, "Error while redirecting to game", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun onEditMatch() {
        SocketUser.socket.socket.on("matchEdit") { data ->
            val json = JSON()
            var jsonObj = json.fromJson(data[0].toString())
            println(jsonObj)
            var type = jsonObj["type"]
            var games: JsonObject = jsonObj["content"] as JsonObject
            if (games["name"] == WaitingRoom.name) {
                when (type) {
                    0 -> {
                        var arrayTeamA = ArrayList<String>()
                        var arrayTeamB = ArrayList<String>()

                        val classicGameobj = games
                        var teamA = classicGameobj["teamA"] as JsonArray<String>
                        var teamB = classicGameobj["teamB"] as JsonArray<String>
                        for (i in 0 until teamA.size) {
                            val A = teamA[i]
                            arrayTeamA.add(A)
                        }
                        for (i in 0 until teamB.size) {
                            val B = teamB[i]
                            arrayTeamB.add(B)
                        }
                        val classic = ClassicGame(
                            classicGameobj["name"] as String,
                            classicGameobj["nbRounds"] as Int,
                            classicGameobj["type"] as Int,
                            classicGameobj["creator"] as String,
                            classicGameobj["playerCount"] as Int,
                            arrayTeamB,
                            arrayTeamA
                        )
                        WaitingRoom.Game = classic
                        if(!onLeave) {
                            activity?.runOnUiThread {
                                updateView()
                            }
                        }

                    }

                    1 -> {
                        val players: ArrayList<String> = ArrayList()
                        val coopgame = games
                        var playersArray = coopgame["players"] as JsonArray<String>
                        for (player in playersArray) {
                            players.add(player)
                        }
                        val coop = CoopGame(
                            coopgame["name"] as String,
                            coopgame["nbRounds"] as Int,
                            coopgame["type"] as Int,
                            coopgame["creator"] as String,
                            coopgame["playerCount"] as Int,
                            players,
                            coopgame["aiplayer"] as String
                        )
                        WaitingRoom.Game = coop
                        if(!onLeave) {
                            activity?.runOnUiThread {
                                updateView()
                            }                        }
                    }


                    2 -> {
                        val duelGameobj = games
                        val duel = DuelGame(
                            duelGameobj["name"] as String,
                            duelGameobj["nbRounds"] as Int,
                            duelGameobj["type"] as Int,
                            duelGameobj["creator"] as String,
                            duelGameobj["playerCount"] as Int,
                            duelGameobj["player1"] as String,
                            duelGameobj["player2"] as String

                        )
                        WaitingRoom.Game = duel
                        if(!onLeave) {
                            activity?.runOnUiThread {
                                updateView()
                            }
                        }
                    }
                }
            }
        }
    }
}