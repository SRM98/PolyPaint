package com.example.polypaintapp

import android.app.Activity
import kotlinx.android.synthetic.main.fragment_lobby_main.*

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.core.graphics.drawable.toDrawable
import androidx.core.net.toUri
import androidx.core.view.isVisible
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.navigation.findNavController
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.fragment_profilview.*
import kotlinx.android.synthetic.main.fragment_profilview.view.*
import kotlinx.android.synthetic.main.fragment_signup.*
import kotlinx.android.synthetic.main.password_dialog.*
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URL


class FragmentProfil(private val supportFragmentManager: FragmentManager) : Fragment() {

    var modifInAvatar: Boolean = false
    val PICKFILE_RESULT_CODE = 1
    var fileUri: Uri = "".toUri()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        getUserInfos()
        return inflater.inflate(R.layout.fragment_profilview, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        profil_lastname.text = User.lastName
        profil_firstName.text = User.firstName
        profil_username.text = User.username

        if(User.avatarUrl != ""){
            val uri = IP + "/" + User.avatarUrl
            Glide.with(this).load(uri.toUri()).into(profil_avatar)
        }

        //make invisible all editTexts and save buttons
        edit_firstname.visibility = View.GONE
        btn_save_firstname.visibility = View.GONE

        profil_firstName.visibility = View.VISIBLE
        firstname_edit_btn.visibility = View.VISIBLE

        edit_lastname.visibility = View.GONE
        btn_save_lastname.visibility = View.GONE

        profil_lastname.visibility = View.VISIBLE
        lastName_edit_btn.visibility = View.VISIBLE

        firstname_edit_btn.setOnClickListener {
            edit_firstname.visibility = View.VISIBLE
            btn_save_firstname.visibility = View.VISIBLE

            profil_firstName.visibility = View.GONE
            firstname_edit_btn.visibility= View.GONE
        }

        lastName_edit_btn.setOnClickListener {
            edit_lastname.visibility = View.VISIBLE
            btn_save_lastname.visibility = View.VISIBLE

            profil_lastname.visibility = View.GONE
            lastName_edit_btn.visibility = View.GONE
        }

        val mainView = view

        btn_save_firstname.setOnClickListener {
            changeFirstName(edit_firstname.text.toString(), mainView)
        }

        btn_save_lastname.setOnClickListener {
            changeLastName(edit_lastname.text.toString(), mainView)
        }

        //Modif in avatar?

        btn_choose_avatar.isVisible = false
        btn_draw_it.isVisible = false
        btn_change_avatar.isVisible = true

        btn_change_avatar.setOnClickListener {
            btn_change_avatar.isVisible = false
            btn_choose_avatar.isVisible = true
            btn_draw_it.isVisible = true
        }

        btn_draw_it.setOnClickListener {
            val transaction = supportFragmentManager.beginTransaction().apply {
                replace(R.id.nav_host_fragment_lobby, FragmentFreeDraw(true, supportFragmentManager))
                addToBackStack(null)
            }
            transaction.commit()
        }

        btn_choose_avatar.setOnClickListener {
            var chooseFile: Intent = Intent(Intent.ACTION_GET_CONTENT)
            chooseFile.setType("*/*")
            chooseFile = Intent.createChooser(chooseFile, "Choose your avatar")
            startActivityForResult(chooseFile, PICKFILE_RESULT_CODE)
        }

        btn_change_password.setOnClickListener {
            val transaction = supportFragmentManager.beginTransaction().apply {
                replace(R.id.nav_host_fragment_lobby, FragmentEditPassword(supportFragmentManager))
                addToBackStack(null)
            }
            transaction.commit()
        }
    }

    fun changeFirstName(firstName: String, mainView: View)
    {
        val http = HttpRequest()
        context?.let {context ->
            val callbackFirstName = CallbackFirstName(context, mainView, activity as Activity, firstName)
            http.putUserFirstName(firstName, callbackFirstName)
        }
    }

    fun changeLastName(lastName: String, mainView: View)
    {
        val http = HttpRequest()
        context?.let {context ->
            val callbackLastName = CallbackLastName(context, mainView, activity as Activity, lastName)
            http.putUserLastName(lastName, callbackLastName)
        }
    }

    fun getUserInfos() {
        val http = HttpRequest()
        http.getUserInfosRequest(User)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            PICKFILE_RESULT_CODE -> if (resultCode === -1) {
                fileUri = data?.getData() as Uri

                val bitmap = MediaStore.Images.Media.getBitmap(activity?.contentResolver, fileUri)
                val stream: ByteArrayOutputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 30, stream)
                val compressedByteArray = stream.toByteArray()

                val http = HttpRequest()
                http.putUserAvatar(compressedByteArray, CallbackAvatar(context!!, compressedByteArray, supportFragmentManager))
            }
        }
    }
}

//class CallbackUsername(private val context: Context, val view: View, val activity: Activity, val newUsername: String): Callback{
//
//    override fun onResponse(call: Call, response: Response) {
//        this.responseState = true
//        responseBody = response.message
//
//        if (responseBody == "OK") {
//            User.username = newUsername
//            activity?.runOnUiThread {
//                view.edit_username.isVisible = false
//                view.btn_save_username.isVisible = false
//
//                view.profil_username.isVisible = true
//                view.profil_username.text = User.username
//                view.username_edit_btn.isVisible = true
//            }
//        } else {
//            (context as AppCompatActivity).runOnUiThread {
//                Toast.makeText(context, response.body?.string(), Toast.LENGTH_SHORT).show()
//            }
//        }
//    }
//
//    override fun onFailure(call: Call, err: IOException) {
//        println(err.toString())
//        responseState = false
//
//        (context as AppCompatActivity).runOnUiThread {
//            Toast.makeText(context, "Connection failed to server!", Toast.LENGTH_SHORT).show()
//        }
//
//        val throwable = Throwable(err.toString())
//        Thread.setDefaultUncaughtExceptionHandler { t, e -> System.err.println(e.message) }
//        throw throwable
//    }
//
//    var responseState: Boolean = false
//    var responseBody: String? = ""
//}

class CallbackFirstName(private val context: Context, val view: View, val activity: Activity, val newFirstName: String): Callback{

    override fun onResponse(call: Call, response: Response) {
        this.responseState = true
        responseBody = response.message

        if (responseBody == "OK") {
            User.firstName = newFirstName
            activity?.runOnUiThread {
                view.edit_firstname.visibility = View.GONE
                view.btn_save_firstname.visibility = View.GONE

                view.profil_firstName.visibility = View.VISIBLE
                view.firstname_edit_btn.visibility= View.VISIBLE

                view.profil_firstName.text = User.firstName

                (context as AppCompatActivity).runOnUiThread {
                    Toast.makeText(context, "Your first name is changed!", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            (context as AppCompatActivity).runOnUiThread {
                Toast.makeText(context, response.body?.string(), Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onFailure(call: Call, err: IOException) {
        println(err.toString())
        responseState = false

        (context as AppCompatActivity).runOnUiThread {
            Toast.makeText(context, "Connection failed to server!", Toast.LENGTH_SHORT).show()
        }

        val throwable = Throwable(err.toString())
        Thread.setDefaultUncaughtExceptionHandler { t, e -> System.err.println(e.message) }
        throw throwable
    }

    var responseState: Boolean = false
    var responseBody: String? = ""
}

class CallbackLastName(private val context: Context, val view: View, val activity: Activity, val newLastName: String): Callback{

    override fun onResponse(call: Call, response: Response) {
        this.responseState = true
        responseBody = response.message

        if (responseBody == "OK") {
            User.lastName = newLastName
            activity?.runOnUiThread {
                view.edit_lastname.visibility = View.GONE
                view.btn_save_lastname.visibility = View.GONE

                view.profil_lastname.visibility = View.VISIBLE
                view.lastName_edit_btn.visibility = View.VISIBLE

                view.profil_lastname.text = User.lastName

                (context as AppCompatActivity).runOnUiThread {
                    Toast.makeText(context, "Your last name is changed!", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            (context as AppCompatActivity).runOnUiThread {
                Toast.makeText(context, response.body?.string(), Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onFailure(call: Call, err: IOException) {
        println(err.toString())
        responseState = false

        (context as AppCompatActivity).runOnUiThread {
            Toast.makeText(context, "Connection failed to server!", Toast.LENGTH_SHORT).show()
        }

        val throwable = Throwable(err.toString())
        Thread.setDefaultUncaughtExceptionHandler { t, e -> System.err.println(e.message) }
        throw throwable
    }

    var responseState: Boolean = false
    var responseBody: String? = ""
}