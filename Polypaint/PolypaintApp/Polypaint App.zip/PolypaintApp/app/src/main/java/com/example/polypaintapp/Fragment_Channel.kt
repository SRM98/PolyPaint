package com.example.polypaintapp

import android.annotation.TargetApi
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.core.view.get
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.navigation.findNavController
import com.beust.klaxon.Json
import com.example.polypaintapp.Channel.name
import com.mikepenz.iconics.Iconics.applicationContext
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.activity_chat.*
import kotlinx.android.synthetic.main.channel_row.view.*
import kotlinx.android.synthetic.main.fragment_channel.*
import kotlinx.android.synthetic.main.fragment_chat.*
import org.json.JSONArray
import java.util.*
import java.util.Arrays.asList
import kotlin.collections.ArrayList


class FragmentChannel : Fragment() {

    private val adapter = GroupAdapter<ViewHolder>()
    private val channelNames = ArrayList<String>()
    private val ownChannels = ArrayList<String>()




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_channel, container, false)
        v.setFocusableInTouchMode(true)
        v.requestFocus()
        v.setOnKeyListener(object : View.OnKeyListener {
            override fun onKey(v: View, keyCode: Int, event: KeyEvent): Boolean {
                if (event.getAction() === KeyEvent.ACTION_DOWN) {
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
                        if(SocketUser.gameModes) {
                            println("test")
                            SocketUser.gameModes = false
                            val intent = Intent(context, Game_Modes::class.java)
                            startActivity(intent)
                        }
                    }
                }
                return false
            }
        })
        return v
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        getOwnRooms()


        adapter.clear()
        recyclerView_channel.adapter = adapter


        SocketUser.socket.getRooms("")
        context?.let { SocketUser.onMessage(it) }
        onChannelRooms()
        SocketUser.socket.getOwnRooms()

        val adapterChannel = ArrayAdapter<String>(
            activity!!.applicationContext,
            android.R.layout.simple_list_item_1,
            channelNames
        )

        autoCompleteTextView.setAdapter(adapterChannel)

        go_to_myChannels.setOnClickListener {Activity ->
            Activity.findNavController().navigate(R.id.action_fragmentChannel_to_fragment_My_Channels)

        }

        autoCompleteTextView.setOnClickListener {
        }

        autoCompleteTextView.setOnItemClickListener(object : AdapterView.OnItemClickListener {

            override fun onItemClick(parent: AdapterView<*>, view: View, position: Int, id: Long) {

                val selected = parent.getItemAtPosition(position) as String
                autoCompleteTextView.text.clear()
                val json = JSON()
                val room = Room(User.username, selected)
                SocketUser.joinedChannels.add(selected)
                SocketUser.socket.join(json.toJson(room))
                SocketUser.socket.getRooms("")
                Toast.makeText(context, "Channel $selected is joined", Toast.LENGTH_SHORT).show()
                activity?.findNavController(R.id.channel_view)?.navigate(R.id.action_fragmentChannel_to_fragment_My_Channels)

            }
        })

        addChannel.setOnClickListener {view ->
            var exists = false
            for (i in 0 until channelNames.size) {
                if(autoCompleteTextView.text.toString() == channelNames[i]) {
                    exists = true


                }
            }
            if(autoCompleteTextView.text.startsWith(" ")  || autoCompleteTextView.text.isBlank()) {
                Toast.makeText(context, "You cannot add this", Toast.LENGTH_SHORT).show()
            }
            else if(exists) {
                Toast.makeText(context, "Channel already exist", Toast.LENGTH_SHORT).show()

            }
            else {
                val json = JSON()
                val room = Room(User.username,autoCompleteTextView.text.toString() )
                SocketUser.socket.createRoom(json.toJson(room))
                Channel.name = autoCompleteTextView.text.toString()
                autoCompleteTextView.text.clear()
                view.findNavController()?.navigate(R.id.action_fragmentChannel_to_fragmentChat)
            }
        }

    }




    override fun onDestroyView() {
        super.onDestroyView()

    }


    fun addChannel(name: String) {

        adapter.add(ChannelItem(name))

    }

    fun getOwnRooms() {

        SocketUser.socket.socket.on("ownRooms", {data ->
            SocketUser.joinedChannels.clear()
            val json = JSON()
            var ownChan = JSONArray(data[0].toString())

            for (i in 0 until ownChan.length()) {
                SocketUser.joinedChannels.add(ownChan[i].toString())
                val room = Room(User.username, ownChan[i].toString())
                SocketUser.socket.join(json.toJson(room))
            }

        })

    }

    fun onChannelRooms() {
        SocketUser.socket.socket.on("allRooms") { data ->
            var chan = JSONArray(data[0].toString())

            activity?.runOnUiThread(java.lang.Runnable {
                adapter?.clear()
                recyclerView_channel?.adapter = adapter
                channelNames.clear()
                for (i in 0 until chan.length()) {
                    channelNames.add(chan[i] as String)
                    addChannel(channelNames[i])
                }})
        }

    }

}

class ChannelItem(var name: String): Item<ViewHolder>() {

    override fun bind(viewHolder: ViewHolder, position: Int) {
        viewHolder.itemView.channel_name.text = name
        if(SocketUser.joinedChannels.contains(name)) {
            viewHolder.itemView.button_leave_channel.visibility = View.VISIBLE
            viewHolder.itemView.button_join_channel.visibility = View.GONE
            viewHolder.itemView.channel_name.isEnabled = true
        }
        else {
            viewHolder.itemView.button_leave_channel.visibility = View.GONE
            viewHolder.itemView.button_join_channel.visibility = View.VISIBLE
            viewHolder.itemView.channel_name.isEnabled = false
        }

        viewHolder.itemView.button_leave_channel.setOnClickListener {
            //SocketUser.joinedChannels.remove(name)
            viewHolder.itemView.channel_name.isEnabled = false
            viewHolder.itemView.button_leave_channel.visibility = View.GONE
            viewHolder.itemView.button_join_channel.visibility = View.VISIBLE
            val room = Room(User.username, name)
            val json = JSON()
            SocketUser.socket.leaveRoom(json.toJson(room))
        }

        viewHolder.itemView.button_join_channel.setOnClickListener {
            //SocketUser.joinedChannels.add(name)
            viewHolder.itemView.channel_name.isEnabled = true
            viewHolder.itemView.button_leave_channel.visibility = View.VISIBLE
            viewHolder.itemView.button_join_channel.visibility = View.GONE
            val room = Room(User.username, name)
            val json = JSON()
            SocketUser.socket.join(json.toJson(room))
        }

        viewHolder.itemView.channel_name.setOnClickListener {Activity ->
            Channel.name = name
            Activity.findNavController().navigate(R.id.action_fragmentChannel_to_fragmentChat)

        }

    }
    override fun getLayout(): Int {
        return R.layout.channel_row
    }

}