package com.example.polypaintapp

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils.replace
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.navigation.findNavController
import kotlinx.android.synthetic.main.design_solo.*
import kotlinx.android.synthetic.main.fragment_create_match.*
import kotlinx.android.synthetic.main.game_modes_choice.*

class Fragment_DesignSolo : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) =
        inflater.inflate(R.layout.design_solo, container, false)!!


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        PLAY.setOnClickListener {VIEW ->

            val json = com.google.gson.JsonObject()
            val json2 = JSON()
            CurrentGameMode.gameMode = GameModes.Solo.ordinal
            WaitingRoom.name = "Solo"
            Channel.name = WaitingRoom.name

            val match = Match("Solo", 3,
                CurrentGameMode.gameMode, User.username)
            SocketUser.socket.createMatch(json2.toJson(match))

            VIEW.findNavController().navigate(R.id.action_fragment_Game_modes_to_fragment_Inmatch)

        }



    }

    override fun onDestroyView() {
        super.onDestroyView()
    }

}