package com.example.polypaintapp

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.beust.klaxon.JsonArray
import com.beust.klaxon.JsonObject
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.fragment_duel.*

import kotlinx.android.synthetic.main.games_row.view.*
import java.util.*
import android.R.attr.name
import android.graphics.Color
import android.widget.SeekBar
import androidx.core.view.isInvisible
import com.divyanshu.draw.widget.DrawView
import com.madrapps.pikolo.listeners.SimpleColorSelectionListener
import kotlinx.android.synthetic.main.activity_paint.*
import kotlinx.android.synthetic.main.fragment_in_match.*
import nl.dionsegijn.konfetti.models.Shape
import nl.dionsegijn.konfetti.models.Size


class RoundInfos {
    constructor(pdrawer: String, pduration: Int, pGuessing: Boolean) {
        drawer = pdrawer
        roundDuration = pduration
        isGuessing = pGuessing
    }

    val drawer: String
    val roundDuration: Int
    val isGuessing: Boolean
}

class Fragment_Inmatch : Fragment() {
    private val adapter = GroupAdapter<ViewHolder>()
    private val gameId = WaitingRoom.name + CurrentGameMode.gameMode.toString()
    private lateinit var handler: Handler
    private var currentTimeRemaining: Int = 0
    private var currentRound = 0
    var strokeColor = 0x000000
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) =
        inflater.inflate(R.layout.fragment_in_match, container, false)!!


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter.clear()
        this.handler = Handler(Looper.getMainLooper())

        setGameInfos()
        onSendGuess()
        onBadGuess()
        onReply()
        onRoundStart()
        onRoundStartDrawer()
        onRoundEnd()
        onMatchEnd()
        initPaint()
    }

    override fun onDestroyView() {
        val json = JSON()
        val request = MatchRequest(User.username, WaitingRoom.name + CurrentGameMode.gameMode.toString())
        SocketUser.socket.leaveMatch(json.toJson(request))
        SocketUser.joinedChannels.remove(WaitingRoom.name)
        super.onDestroyView()
    }

    private fun setGameInfos() {
        gameNameInmatch.text = WaitingRoom.name
        when {
            WaitingRoom.Game is ClassicGame -> {
                val game = WaitingRoom.Game as ClassicGame
                nbRoundsInmatch.text = "${currentRound}/${game.nbRounds} rounds"
                game.teamA.forEach { member ->
                    teamA.text = "${teamA.text} \n\t $member"
                }
                game.teamB.forEach { member ->
                    teamB.text = "${teamB.text} \n\t $member"
                }
            }
            WaitingRoom.Game is DuelGame -> {
                val game = WaitingRoom.Game as DuelGame
                nbRoundsInmatch.text = "${currentRound}/${game.nbRounds} rounds"
                teamA.text = "${game.player1} vs ${game.player2}"
                teamB.text = ""
            }
            WaitingRoom.Game is CoopGame -> {
                val game = WaitingRoom.Game as CoopGame
                nbRoundsInmatch.text = ""
                teamA.text = "Ai player is ${game.aiplayer}"
                teamB.text = "Current players:"
                game.players.forEach { member ->
                    teamB.text = "${teamB.text}\n\t $member"
                }
            }
            WaitingRoom.Game is SoloGame -> {
                val game = WaitingRoom.Game as SoloGame
                nbRoundsInmatch.text = ""
                teamA.text = "Ai player is ${game.aiplayer}"
                teamB.text = ""

            }
        }
    }

    private fun onRoundEnd() {
        SocketUser.socket.socket.on("roundEnd") { data ->
            activity?.runOnUiThread {
                val roundEndJson = JsonParser().parse(data[0].toString()).asJsonObject
                val roundEndMessage = roundEndJson.get("message").toString()
                currentTimeRemaining = 0
                timeRemaining.text = "The round is finish"
                Toast.makeText(activity, roundEndMessage, Toast.LENGTH_SHORT).show()
                val teamAPoints = roundEndJson.get("teamA").toString().toInt()
                val teamBPoints = roundEndJson.get("teamB")?.toString()?.toInt()
            }
        }
    }

    private fun onRoundStartDrawer() {
        SocketUser.socket.socket.on("roundStartDrawer") { data ->

            activity?.runOnUiThread {
                val roundJson = JsonParser().parse(data[0].toString()).asJsonObject
                val word = roundJson.get("wordToDraw").toString()
                wordToDraw.text = "Word to draw: $word"
            }
        }
    }

    private fun onMatchEnd() {
        SocketUser.socket.socket.on("matchEnd") { data ->
            activity?.runOnUiThread {
                viewKonfetti.build()
                    .addColors(Color.YELLOW, Color.GREEN, Color.MAGENTA)
                    .setDirection(0.0, 359.0)
                    .setSpeed(1f, 5f)
                    .setFadeOutEnabled(true)
                    .setTimeToLive(2000L)
                    .addShapes(Shape.RECT, Shape.CIRCLE)
                    .addSizes(Size(12))
                    .setPosition(-50f, viewKonfetti.width + 50f, -50f, -50f)
                    .streamFor(300, 5000L)

                val matchEndJson = JsonParser().parse(data[0].toString()).asJsonObject
                val reason = matchEndJson.get("reason")?.toString()
                val wins = matchEndJson.get("wins")?.toString()?.toBoolean()
                if (reason != null && wins != null) {
                    if (reason.isNotEmpty()) {
                        if (wins!!) {
                            Toast.makeText(
                                activity,
                                "Congrats you won the game!!",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(activity, "Sorry you lost!", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(activity, reason, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            val json = JSON()
            val request = MatchRequest(User.username, WaitingRoom.name + CurrentGameMode.gameMode.toString())
            SocketUser.socket.leaveMatch(json.toJson(request))
            SocketUser.joinedChannels.remove(WaitingRoom.name)
        }
    }

    private fun updateTimeRemaining() {
        currentTimeRemaining--
        if (currentTimeRemaining <= 0) {
            timeRemaining?.text = "There is no time remaining"
            guessesLeft?.text = "Guesses left: 0"
            enterGuess?.visibility = View.GONE
            sendGuess?.visibility = View.GONE
        } else {
            timeRemaining?.text = "Time Remaining: $currentTimeRemaining"
        }

    }

    private val runnable = object : Runnable {
        override fun run() {
            updateTimeRemaining()
            if (currentTimeRemaining > 0) {
                handler.postDelayed(this, 1000)
            }
        }
    }
    private fun onRoundStart() {
        SocketUser.socket.socket.on("roundStart") { data ->
            val gson = Gson()
            val roundJson = JsonParser().parse(data[0].toString()).asJsonObject
            val round = gson.fromJson(roundJson, RoundInfos::class.java)
            if (currentTimeRemaining <= 0)
                handler.postDelayed(runnable, 1000)
            currentTimeRemaining = round.roundDuration
            activity?.runOnUiThread {
                if (round.isGuessing) {
                    enterGuess.visibility = View.VISIBLE
                    sendGuess.visibility = View.VISIBLE
                } else {
                    enterGuess.visibility = View.GONE
                    sendGuess.visibility = View.GONE
                }
                if (round.drawer == User.username) {
                    showTools()
                } else {
                    removeTools()
                }
                clearCanvas()
            }
        }
    }

    private fun onSendGuess() {
        sendGuess.setOnClickListener {
            val guess = enterGuess.text.toString().trim()
            if (guess.isEmpty()) {
                Toast.makeText(activity, "Please enter a guess", Toast.LENGTH_SHORT).show()
            } else {
                val guessJson = com.google.gson.JsonObject()
                guessJson.addProperty("guess", guess)
                guessJson.addProperty("id", gameId)
                SocketUser.socket.socket.emit("guess", guessJson)
            }
        }
    }

    private fun onBadGuess() {
        SocketUser.socket.socket.on("badGuess") { data ->
            activity?.runOnUiThread {
                val numberTriesJson = JsonParser().parse(data[0].toString()).asJsonObject
                val nbTries = numberTriesJson.get("triesLeft").toString().toInt()
                guessesLeft.text = "Guesses left: $nbTries"
            }
        }
    }

    fun onReply() {
        SocketUser.socket.socket.on("reply") { data ->
            activity?.runOnUiThread {
                val numberTriesJson = JsonParser().parse(data[0].toString()).asJsonObject
                if (currentTimeRemaining <= 0)
                    handler.postDelayed(runnable, 1000)
                currentTimeRemaining = numberTriesJson.get("roundDuration").toString().toInt()
                val isGuessing = numberTriesJson.get("isGuessing").toString().toBoolean()
                if (isGuessing != null) {
                    if (isGuessing) {
                        Toast.makeText(activity, "It's your time to guess", Toast.LENGTH_SHORT).show()
                        enterGuess?.visibility = View.VISIBLE
                        sendGuess?.visibility = View.VISIBLE
                    } else {
                        Toast.makeText(activity, "It's time for your opponent to guess", Toast.LENGTH_SHORT).show()
                        enterGuess?.visibility = View.INVISIBLE
                        sendGuess?.visibility = View.INVISIBLE
                    }
                }
            }
        }
    }
    fun startSetup() {
        seekBar_width.visibility = View.GONE
        color_picker.visibility = View.GONE
        stroke_change_square.isInvisible = false
        stroke_change_round.isInvisible = true
        draw_view.setStrokeWidth(50.0f)
    }

    fun changeStroke(round : Boolean) {
        if(round) {
            draw_view.changeStrokeCapToRound()
        }
        else {
            draw_view.changeStrokeCapToSquare()
        }
    }
    fun removeTools() {
        draw_tools.visibility = View.INVISIBLE
        draw_view.deactivateDraw()
    }

    fun showTools() {
        draw_tools.visibility = View.VISIBLE
        draw_view.activateDraw()
    }

    fun clearCanvas() {
        draw_view.clearCanvas()
    }

    fun initPaint() {

        draw_view.setSocket(SocketUser.socket.socket)
        draw_view.setRoom(WaitingRoom.name + CurrentGameMode.gameMode)
        draw_view.setStrokeWidth(50.0f)


        color_picker.setColorSelectionListener(object : SimpleColorSelectionListener() {
            override fun onColorSelected(color: Int) {
                // Do whatever you want with the color
                draw_view.setColor(color)
            }
        })

        startSetup()

        save_image.setOnClickListener {

            draw_view.saveImageToExternalStorage(draw_view.getBitmap())
        }

        stroke_change_round.setOnClickListener {

            changeStroke(true)
            stroke_change_square.isInvisible = false
            stroke_change_round.isInvisible = true
        }

        stroke_change_square.setOnClickListener {

            changeStroke(false)
            stroke_change_square.isInvisible = true
            stroke_change_round.isInvisible = false
        }

        image_draw_eraser.setOnLongClickListener {
            draw_view.clearCanvas()
            true
        }

        image_draw_eraser.setOnClickListener {

            strokeColor = 0xFFFFFF
            draw_view.setColor(strokeColor)
        }

        image_draw_width.setOnClickListener {

            draw_view.setColor(strokeColor)
            color_picker.visibility = View.GONE
            if(seekBar_width.visibility == View.VISIBLE)
                seekBar_width.visibility = View.GONE
            else
                seekBar_width.visibility = View.VISIBLE

        }

        image_draw_color.setOnClickListener {

            seekBar_width.visibility = View.GONE
            if(color_picker.visibility == View.VISIBLE)
                color_picker.visibility = View.GONE
            else
                color_picker.visibility = View.VISIBLE
        }

        seekBar_width.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                draw_view.setStrokeWidth(progress.toFloat())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }
}