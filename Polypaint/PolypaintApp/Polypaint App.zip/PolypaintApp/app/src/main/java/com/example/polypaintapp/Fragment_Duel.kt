package com.example.polypaintapp

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.beust.klaxon.JsonArray
import com.beust.klaxon.JsonObject
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.fragment_classique.*
import kotlinx.android.synthetic.main.fragment_duel.*
import kotlinx.android.synthetic.main.games_row.view.*

class Fragment_Duel : Fragment() {
    private val adapter = GroupAdapter<ViewHolder>()
    private val DuelGamesArr = ArrayList<DuelGame>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v = inflater.inflate(R.layout.fragment_duel, container, false)
        //Back pressed Logic for fragment
        v.setFocusableInTouchMode(true)
        v.requestFocus()
        v.setOnKeyListener(object : View.OnKeyListener {
            override fun onKey(v: View, keyCode: Int, event: KeyEvent): Boolean {
                if (event.getAction() === KeyEvent.ACTION_DOWN) {
                    if (keyCode == KeyEvent.KEYCODE_BACK) {

                        val intent = Intent(context, Game_Modes::class.java)

                        startActivity(intent)
                    }
                }
                return false
            }
        })
        // Inflate the layout for this fragment
        return v
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        chatButton_duel.setOnClickListener {view ->

            view.findNavController().navigate(R.id.action_fragment_Duel_to_nav_graph_chat)
        }

        adapter.clear()
        recycle_view_duel.adapter = adapter
        getDuelMatches()
        createDuel.setOnClickListener{ Activity ->
            CurrentGameMode.gameMode = GameModes.Duel.ordinal
            Activity?.findNavController()?.navigate(R.id.action_fragment_Duel_to_fragment_CreateMatch)
        }
        onMatchCreated()
    }

    fun addDuelGame(game : DuelGame) {

        adapter.add(DuelItem(game))

    }

    fun onMatchCreated() {
        SocketUser.socket.socket.on("matchCreated") { data ->
            val json = JSON()
            var jsonObj = json.fromJson(data[0].toString())
            var type = jsonObj["type"]
            if (type == 2) {
                var games: JsonObject = jsonObj["content"] as JsonObject
                println(games)
                val duelGameobj = games
                    val duel = DuelGame(
                        duelGameobj["name"] as String,
                        duelGameobj["nbRounds"] as Int,
                        duelGameobj["type"] as Int,
                        duelGameobj["creator"] as String,
                        duelGameobj["playerCount"] as Int,
                        duelGameobj["player1"] as String,
                        duelGameobj["player2"] as String

                    )
                    activity?.runOnUiThread(java.lang.Runnable {
                        addDuelGame(duel)
                    })
                }


        }
    }


    fun getDuelMatches() {

        val json = JSON()
        SocketUser.socket.socket.emit("getMatches", json.toJson(GameRequest(2)))
        SocketUser.socket.socket.on("getMatches") { data ->

            activity?.runOnUiThread(java.lang.Runnable {
                adapter.clear()
            })

            var jsonObj = json.fromJson(data[0].toString())
            var type = jsonObj["type"]
            if (type == 2) {
            var games = jsonObj["content"] as JsonArray<JsonObject>

            DuelGamesArr.clear()
            for (i in 0 until games.size) {
                val duelGameobj = games[i]
                    val duel = DuelGame(
                        duelGameobj["name"] as String,
                        duelGameobj["nbRounds"] as Int,
                        duelGameobj["type"] as Int,
                        duelGameobj["creator"] as String,
                        duelGameobj["playerCount"] as Int,
                        duelGameobj["player1"] as String,
                        duelGameobj["player2"] as String

                    )
                    DuelGamesArr.add(duel)
                    activity?.runOnUiThread(java.lang.Runnable {
                        addDuelGame(duel)
                    })
                }
            }
        }

    }
}


class DuelItem(var Cgame : DuelGame): Item<ViewHolder>() {

    val json = JSON()
    var gotIt = false

    fun onJoin() {
        SocketUser.socket.socket.on("matchJoined") { data ->

            var jsonObj = json.fromJson(data[0].toString())
            var type = jsonObj["type"]
            if (type == 2) {
                var games: JsonObject = jsonObj["content"] as JsonObject
                println(games)
                val duelGameobj = games
                if (duelGameobj["name"] as String == Cgame.name) {
                    val duel = DuelGame(
                        duelGameobj["name"] as String,
                        duelGameobj["nbRounds"] as Int,
                        duelGameobj["type"] as Int,
                        duelGameobj["creator"] as String,
                        duelGameobj["playerCount"] as Int,
                        duelGameobj["player1"] as String,
                        duelGameobj["player2"] as String

                    )
                    WaitingRoom.Game = duel
                    gotIt = true

                }

            }


        }

    }
    override fun bind(viewHolder: ViewHolder, position: Int) {
        onJoin()
        viewHolder.itemView.game_name.text = Cgame.name
        viewHolder.itemView.game_participants.text = Cgame.playerCount.toString()

        viewHolder.itemView.game_name.setOnClickListener {

        }

        viewHolder.itemView.button_join_game.setOnClickListener { Activity ->
            CurrentGameMode.gameMode = 2
            WaitingRoom.name = Cgame.name



            SocketUser.socket.joinMatch(json.toJson(MatchRequest(User.username, Cgame.name + CurrentGameMode.gameMode.toString())))
            SocketUser.joinedChannels.add(Cgame.name)
            while(!gotIt){}
            Activity.findNavController()?.navigate(R.id.action_fragment_Duel_to_fragment_WaitingRoom)
        }


        viewHolder.itemView.game_participants.setOnClickListener {

        }

    }

    override fun getLayout(): Int {
        return R.layout.games_row
    }
}

