package com.example.polypaintapp

import android.app.Activity
import android.app.PendingIntent.getActivity
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.beust.klaxon.JsonArray
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager.*
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.activity_game_modes.*
import kotlinx.android.synthetic.main.channel_row.view.*
import kotlinx.android.synthetic.main.fragment_channel.*
import kotlinx.android.synthetic.main.fragment_classique.*
import kotlinx.android.synthetic.main.game_modes_choice.*
import kotlinx.android.synthetic.main.games_row.view.*
import org.json.JSONArray

class Game_Modes : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_modes)



    }


}