package com.example.polypaintapp

class Stats {

    constructor(nbGames: Number, nbGamesCoop: Number, nbGamesSolo: Number, nbVictories: Number, victoryPercentage: Number, averageMatchesTime: Number,
                totalMatchesTime: Number) {
        this.nbGames = nbGames
        this.nbGamesCoop = nbGamesCoop
        this.nbGamesSolo = nbGamesSolo
        this.nbVictories = nbVictories
        this.victoryPercentage = victoryPercentage
        this.averageMatchesTime = averageMatchesTime
        this.totalMatchesTime = totalMatchesTime
    }

    val nbGames: Number
    val nbGamesCoop: Number
    val nbGamesSolo: Number
    val nbVictories: Number
    val victoryPercentage: Number
    val averageMatchesTime: Number
    val totalMatchesTime: Number
}