package com.example.polypaintapp

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import androidx.navigation.findNavController
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_chat.*
import okhttp3.*
import java.io.IOException
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import com.mikepenz.iconics.Iconics.applicationContext


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        SocketUser.socket.connect(this as Context)
        SocketUser.onMessage(this)


    }
}

enum class GameModes {
    Classic,
    Coop,
    Duel,
    Solo
}

object CurrentGameMode {
    var gameMode: Int = GameModes.Classic.ordinal
}

object Channel {
    var name: String = ""
}

object WaitingRoom {
    var name : String = ""
    var Game : Any = ""

}

object SocketUser {
    var gameModes = false
    var socket = Socket()
    var joinedChannels = ArrayList<String>()
    var notif = Notification()

    fun onMessage(context: Context) {
        socket.socket.on("message") { data ->
            var json = JSON()
            val messageReturn = json.fromJson(data[0].toString())

            if(joinedChannels.contains(messageReturn["room"] as String) && User.username != messageReturn["sender"] as String) {
                notif.createNotification(context, messageReturn["room"] as String, messageReturn["text"] as String, messageReturn["room"] as String + " Channel")
                notif.createNotificationChannel(messageReturn["room"] as String)
                notif.showNotification(joinedChannels.indexOf(messageReturn["room"] as String), context)
            }
        }
    }
}




