package com.example.polypaintapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.beust.klaxon.JsonArray
import com.beust.klaxon.JsonObject
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.fragment_solo.*
import kotlinx.android.synthetic.main.games_row.view.*

class fragment_sprint_solo : Fragment() {

    private val adapter = GroupAdapter<ViewHolder>()
    private val soloGames = ArrayList<SoloGame>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        inflater.inflate(R.layout.fragment_solo, container, false)!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        adapter.clear()
        recycle_view_solo.adapter = adapter

        getSoloMatches()
        createSolo.setOnClickListener{ Activity ->
            CurrentGameMode.gameMode = GameModes.Solo.ordinal
            //Activity?.findNavController()?.navigate(R.id.action_fragment_sprint_solo_to_fragment_CreateMatch)
        }

    }


    fun addSoloGame(soloGame: SoloGame) {

        adapter.add(SoloItem(soloGame))

    }

    fun getSoloMatches() {
        val json = JSON()
        SocketUser.socket.socket.emit("getMatches", json.toJson(GameRequest(3)))
        SocketUser.socket.socket.on("getMatches") { data ->
            var jsonObj = json.fromJson(data[0].toString())
            var type = jsonObj["type"]
            if (type == 3) {
                var games = jsonObj["content"] as JsonArray<JsonObject>

                soloGames.clear()
                for (i in 0 until games.size) {
                    val sologame = games[i]
                        println(sologame["name"])
                        val solo = SoloGame(
                            "test",
                            3,
                            10,
                            "ssssss",
                            4,
                            "test"
                        )
                        soloGames.add(solo)
                        activity?.runOnUiThread(java.lang.Runnable {
                            addSoloGame(solo)
                        })
                    }
                }

        }
    }
}



class SoloItem(var Cgame : SoloGame): Item<ViewHolder>() {

    override fun bind(viewHolder: ViewHolder, position: Int) {
        viewHolder.itemView.game_name.text = Cgame.name
        viewHolder.itemView.game_participants.text = Cgame.playerCount.toString()

        viewHolder.itemView.game_name.setOnClickListener {

        }

        viewHolder.itemView.button_join_game.setOnClickListener {

        }

        viewHolder.itemView.game_participants.setOnClickListener {

        }

    }

    override fun getLayout(): Int {
        return R.layout.games_row
    }
}

