package com.example.polypaintapp

class Account {

    constructor(firstName: String, lastName: String, username: String, password: String, imageData: ByteArray, avatarUrl: String, firstTimeUser: Boolean,
                joinedRooms: Array<String>, stats: Stats) {

        this.firstName = firstName
        this.lastName = lastName
        this.username = username
        this.password = password
        this.imageData = imageData
        this.avatarUrl = avatarUrl
        this.firstTimeUser = firstTimeUser
        this.joinedRooms = joinedRooms
        this.stats = stats
    }

    val firstName: String
    val lastName: String
    val username: String
    val password: String
    val imageData: ByteArray
    val avatarUrl: String
    val firstTimeUser: Boolean
    val joinedRooms: Array<String>
    val stats: Stats
}