package com.example.polypaintapp

//val IP = "http://10.200.27.245:4200"
val IP = "http://192.168.0.122:4200"

//"http://18.188.161.175:4200"
