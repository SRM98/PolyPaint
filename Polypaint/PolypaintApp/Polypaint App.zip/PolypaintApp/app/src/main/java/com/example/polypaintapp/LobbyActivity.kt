package com.example.polypaintapp

import android.app.Activity
import android.content.Intent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.util.AttributeSet
import android.view.*
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.net.toUri
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import kotlinx.android.synthetic.main.activity_lobby.*
import com.divyanshu.draw.R.*
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.mikepenz.iconics.typeface.library.googlematerial.GoogleMaterial
import com.mikepenz.materialdrawer.AccountHeader
import com.mikepenz.materialdrawer.AccountHeaderBuilder
import com.mikepenz.materialdrawer.Drawer
import com.mikepenz.materialdrawer.DrawerBuilder
import com.mikepenz.materialdrawer.model.DividerDrawerItem
import com.mikepenz.materialdrawer.model.PrimaryDrawerItem
import com.mikepenz.materialdrawer.model.ProfileDrawerItem
import com.mikepenz.materialdrawer.model.SecondaryDrawerItem
import com.mikepenz.materialdrawer.model.interfaces.IDrawerItem
import com.mikepenz.materialdrawer.model.interfaces.IProfile
import kotlinx.android.synthetic.main.fragment_profilview.*
import kotlinx.android.synthetic.main.password_dialog.*
import org.json.JSONArray


class LobbyActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lobby)
        SocketUser.onMessage(this as Context)
        getMyRooms()
        SocketUser.socket.getOwnRooms()


        supportFragmentManager.popBackStack()
        val transaction = supportFragmentManager.beginTransaction().apply {
            replace(R.id.nav_host_fragment_lobby, FragmentLobby())
            addToBackStack(null)
        }
        transaction.commit()

        println(User.avatarUrl)
        val uri = IP + "/" + User.avatarUrl

        var drawer: Drawer? = null

        var bitmap: Bitmap? = null
        Glide.with(this).asBitmap().load(uri.toUri()).into(object :CustomTarget<Bitmap>(){
            override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                bitmap = resource
                drawer = createDrawer(bitmap as Bitmap)
                User.avatarBitmap = bitmap
            }

            override fun onLoadCleared(placeholder: Drawable?) {
            }
        })

        drawerButton.setOnClickListener {
            drawer?.openDrawer()
        }

    }

    override fun onCreateView(name: String, context: Context, attrs: AttributeSet): View? {
         return super.onCreateView(name, context, attrs)
    }

    fun getMyRooms() {

        SocketUser.socket.socket.on("ownRooms") { data ->
            SocketUser.joinedChannels.clear()
            val json = JSON()
            var ownChan = JSONArray(data[0].toString())
            for (i in 0 until ownChan.length()) {
                SocketUser.joinedChannels.add(ownChan[i].toString())
                val room = Room(User.username, ownChan[i].toString())
                SocketUser.socket.join(json.toJson(room))
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.toolbar_options, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if(id == R.id.action_settings){
            return true
        } else {
            return super.onOptionsItemSelected(item)

        }
    }


    fun createDrawer(bitmap: Bitmap): Drawer{

        val headerResult = AccountHeaderBuilder()
            .withActivity(this)
            .addProfiles(
                ProfileDrawerItem().withName(User.username).withIcon(bitmap)
            )
            .withProfileImagesClickable(true)
            .withOnAccountHeaderProfileImageListener(object: AccountHeader.OnAccountHeaderProfileImageListener{
                override fun onProfileImageClick(view: View, profile: IProfile<*>, current: Boolean): Boolean {
                    val transaction = supportFragmentManager.beginTransaction().apply {
                        replace(R.id.nav_host_fragment_lobby, FragmentProfil(supportFragmentManager))
                        addToBackStack(null)
                    }

                    transaction.commit()

                    return false
                }

                override fun onProfileImageLongClick(
                    view: View,
                    profile: IProfile<*>,
                    current: Boolean
                ): Boolean {
                    return false
                }
            })
            .build()

        val item_gameModes = PrimaryDrawerItem().withIdentifier(1).withName(R.string.item_lobby).withIcon(GoogleMaterial.Icon.gmd_home)
        val item_freeDraw = PrimaryDrawerItem().withIdentifier(2).withName(R.string.item_freeDraw)
        val item_settings = PrimaryDrawerItem().withIdentifier(3).withName(R.string.item_settings).withIcon(GoogleMaterial.Icon.gmd_perm_data_setting)
        val item_leaderboard = PrimaryDrawerItem().withIdentifier(4).withName(R.string.item_leaderBoard)

        val item_signOut = SecondaryDrawerItem().withIdentifier(5).withName(R.string.item_signOut).withIcon(GoogleMaterial.Icon.gmd_exit_to_app)

        val result = DrawerBuilder()
            .withAccountHeader(headerResult)
            .withActivity(this)
            .addDrawerItems(
                item_gameModes,
                item_freeDraw,
                item_settings,
                item_leaderboard,
                DividerDrawerItem(),
                item_signOut
            )
            .withTranslucentStatusBar(false)
            .withActionBarDrawerToggle(false)
            .withOnDrawerItemClickListener(object : Drawer.OnDrawerItemClickListener {
                override fun onItemClick(view: View?, position: Int, drawerItem: IDrawerItem<*>): Boolean {
                    // do something with the clicked item :D

                    when(drawerItem.identifier)
                    {
                        1.toLong() -> {
                            val transaction = supportFragmentManager.beginTransaction().apply {
                                replace(R.id.nav_host_fragment_lobby, FragmentLobby())
                                addToBackStack(null)
                            }
                            transaction.commit()

                        }

                        2.toLong() -> {
                            val transaction = supportFragmentManager.beginTransaction().apply {
                                replace(R.id.nav_host_fragment_lobby, FragmentFreeDraw(false, supportFragmentManager))
                                addToBackStack(null)
                            }
                            transaction.commit()
                        }

                        3.toLong() -> {
                            val transaction = supportFragmentManager.beginTransaction().apply {
                                replace(R.id.nav_host_fragment_lobby, FragmentSettings())
                                addToBackStack(null)
                            }
                            transaction.commit()
                        }

                        4.toLong() -> {
                            val transaction = supportFragmentManager.beginTransaction().apply {
                                replace(R.id.nav_host_fragment_lobby, FragmentLeaderBoard())
                                addToBackStack(null)
                            }
                            transaction.commit()
                        }

                        6.toLong() -> {
                            val transaction = supportFragmentManager.beginTransaction().apply {
                                replace(R.id.nav_host_fragment_lobby, FragmentChannel())
                                addToBackStack(null)
                            }
                            transaction.commit()
                        }

                        5.toLong() -> {
                            SocketUser.socket.disconnectUser()
                            finish()
                        }
                    }

                    return false
                }

            })
            .build()
        return result
    }
}
