package com.example.polypaintapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class LostConnectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lost_connection)
    }
}