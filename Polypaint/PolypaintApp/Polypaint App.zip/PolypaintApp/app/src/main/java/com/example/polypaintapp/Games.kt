package com.example.polypaintapp

class ClassicGame {

    constructor(name: String, nbRounds: Int, type: Int, creator: String, playerCount: Int,  teamA : ArrayList<String>, teamB : ArrayList<String>) {
        this.name = name
        this.nbRounds = nbRounds
        this.type = type
        this.creator = creator
        this.playerCount = playerCount
        this.teamA = teamA
        this.teamB = teamB



    }

    val name: String
    val nbRounds: Int
    val type: Int
    val creator: String
    val playerCount: Int
    var teamA =  ArrayList<String>()
    var teamB =  ArrayList<String>()

}

class CoopGame {

    constructor(name: String, nbRounds: Int, type: Int, creator: String, playerCount: Int, players : ArrayList<String>, aiplayer : String) {
        this.name = name
        this.nbRounds = nbRounds
        this.type = type
        this.creator = creator
        this.playerCount = playerCount
        this.players = players
        this.aiplayer = aiplayer

    }

    val name: String
    val nbRounds: Int
    val type: Int
    val creator: String
    val playerCount: Int
    var players =  ArrayList<String>()
    val aiplayer : String

}

class DuelGame {

    constructor(name: String, nbRounds: Int, type: Int, creator: String, playerCount: Int, player1 : String, player2 : String) {
        this.name = name
        this.nbRounds = nbRounds
        this.type = type
        this.creator = creator
        this.playerCount = playerCount
        this.player1 = player1
        this.player2 = player2


    }

    val name: String
    val nbRounds: Int
    val type: Int
    val creator: String
    val playerCount: Int
    val player1 : String
    val player2 : String




}

class SoloGame {

    constructor(name: String, nbRounds: Int, type: Int, creator: String, playerCount: Int, aiplayer : String) {
        this.name = name
        this.nbRounds = nbRounds
        this.type = type
        this.creator = creator
        this.playerCount = playerCount
        this.aiplayer = aiplayer

    }

    val name: String
    val nbRounds: Int
    val type: Int
    val creator: String
    val playerCount: Int
    val aiplayer : String

}